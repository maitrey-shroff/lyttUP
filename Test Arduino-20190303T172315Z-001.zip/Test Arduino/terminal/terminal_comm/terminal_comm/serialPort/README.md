# Connect-And-Use-Arduino-via-Cpp-Software-Made-In-Any-IDE
Learn to make use of Arduino using your software designed in C++, Python, or Java in your electronic projects.

DISCLAMER:
This Serial library is not created by me, however, the code written to use this library is written by me. This is an open-source library and code so use, merge, or distribute it anywhere you want without any permissions required.
<hr>
CLICK ON PICTURE TO WATCH THIS TUTORIAL BEFORE DOING ANYTHING -- HIGHLY RECOMMENDED
<hr>
<a href="http://www.youtube.com/watch?feature=player_embedded&v=8BWjyZxGr5o" target="_blank">
  <img src="http://img.youtube.com/vi/8BWjyZxGr5o/0.jpg" 
       alt="IMAGE ALT TEXT HERE" width="320" height="240" border="10" />
</a>
